import {combineReducers} from 'redux';
import counterReducer from './counteReducers';

const counterApp =  combineReducers(
    {
        counterReducer
    }
)

export default counterApp