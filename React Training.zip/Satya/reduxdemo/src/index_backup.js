import {createStore,applyMiddleware,combineReducers} from 'redux'
import logger from 'redux-logger'
import {composeWithDevTools} from "redux-devtools-extension";



const userReducer = (state = {},action) =>{
    switch(action.type){
        case "CHANGE_NAME":{
            state = {...state,name:action.payload}
        }
        case "CHANGE_AGE":{
            state = {...state,age:action.payload}
        }
    }
    return state;
}

const tweetReducer = (state=[],action) =>{
    return state
}


const error = (store) => (next) => (action) =>{
    try{
        next(action)
    }catch(e){
        console.log('error',e)
    }
}



//const middleware = applyMiddleware(logger,error);
const reducers = combineReducers({
    user:userReducer,
    tweet:tweetReducer
});
const store = createStore(reducers,composeWithDevTools(applyMiddleware(logger)));

store.subscribe(() =>{
    console.log("Stored changed:"+store.getState())
}
);

store.dispatch({type:"CHANGE_NAME",payload:"Satya"});
store.dispatch({type:"CHANGE_AGE",payload:29});

import {combineReducers,applyMiddleware, createStore } from "redux";
import logger from "redux-logger";
import thunk from "redux-thunk";
import axios from "axios";
import { composeWithDevTools } from "redux-devtools-extension";
// // create Reducer
// const reducer=(state,action)=>{
//    // let initState = {...state};
//     if(action.type==='INC'){
//     return state+action.payload;
//     }
//     if(action.type==='DEC'){
//         return state-action.payload;
//     }
//     if(action.type==='E'){
//         throw new Error("Throwing error");
//     }
//     return state;
//     }

// //Custom logger
// const mylogger=(store)=>(next)=>(action) =>{
//     console.log("action fired",action);
//     next(action)
// }
// //Customer error middleware
// const error=(store)=> (next)=>(action)=>{
//     try{
//         next(action);
//     }catch(e){
//         console.log("error",e)
//     }
// }
//     //middleware
//     const middleware=applyMiddleware(logger,mylogger,error);
// //creatingn store and attach reducer with initial state
// const store = createStore(reducer,1,middleware);

// //subcribe to state to get new state
// store.subscribe(()=>{
//     console.log("store changed"+store.getState().data)
// });

// //dispatch action to invoke reducer
// store.dispatch({type:"INC",payload:1});
// store.dispatch({type:"INC",payload:10});
// store.dispatch({type:"DEC",payload:14});
// store.dispatch({type:"E",payload:30});
//-----------
//Level2

// const userReducer=(state={},action)=>{
//     switch (action.type) {
//         case "CHANGE_NAME":
//             state={...state,name:action.payload}
        
//             break;
//             case "CHANGE_AGE":
//             state={...state,age:action.payload}
            
//             break;
//         default:
//             break;
//     }
//     return state;
// }

// const tweetReducer = (state=[],action)=>{
//     return state;
// }

// const reducers=combineReducers(
//     {
//         user:userReducer,
//         tweet:tweetReducer
//     }
// );

// const store=createStore(reducers,composeWithDevTools(applyMiddleware(logger)));

// store.subscribe(()=>{
//     console.log("store changed"+store.getState())
// });
// store.dispatch({type:'CHANGE_NAME',payload:"Murthy"});
// store.dispatch({type:'CHANGE_AGE',payload:30});

const initialState={
    fetching:false,
    fetch:false,
    user:[],
    error:null
}


const reducer = (state = initialState, action) => {
    switch (action.type) {
        case "FETCH_USERS_START":
            return {...state,fetching:true}
        case "FETCH_USER_ERROR":
            return {...state,error:action.payload}
        case "RECEIVE_USERS":
            return {...state,fetching:false,
            fetched:true,
        users:action.payload}
    }
}

const middleware=applyMiddleware(thunk, logger);
const store = createStore(reducer,middleware);

store.dispatch((dispatch)=>{
     dispatch({type:"FETCH_USERS_START"})
     axios.get("https://jsonplaceholder.typicode.com/users")
     .then((response)=>{
         dispatch({type:"RECEIVE_USERS",payload:response});
     })
     .catch((err)=>{
        dispatch({type:"FETCH_USER_ERROR",payload:err});
     })
})