import React, { Component } from 'react';
export  class Home extends Component {
  render() {
    return (
      <div>
       <h1>Welcome to Cars Management Project</h1>
       <h3>dsrmurthy786@yahoo.com</h3>
      </div>
    );
  }
}