import React from 'react';

export const Greet = ({match}) => (
    <div>
        <p>dsadsadsda</p>
    </div>
)