import data  from '../store/store'
export default (state=null, action)=> {
    // returning initial state of trainer list
        return state=data;
}