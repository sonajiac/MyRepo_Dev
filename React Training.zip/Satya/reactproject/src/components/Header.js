import React, { Component } from 'react';


class Header extends Component {
    render() {
        return (
        <div>
            <h2 className = "text-info text-denter"> React Project </h2>
            <h3> VERIZON </h3> {this.props.tt}
        </div>
        );
    }
}
Header.defaultProps = {
    tt:'WC rooooo'
};

export default Header;
