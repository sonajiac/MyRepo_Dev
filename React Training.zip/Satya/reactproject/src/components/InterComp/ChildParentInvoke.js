import React, { Component } from 'react';


export default class ChildParentInvoke extends Component {
    constructor(props){
        super(props);
        this.state = {data:'Initial Data..'}

        //Best Practise
        this.updateState = this.updateState.bind(this);
        
    };

    updateState(event){
        this.setState({data:event.target.value});
    }
    
    render(){
        return(
            <div>
                <h1 className='well text-success'>Parent Comp</h1>
                <h2 className='text-danger bg-success'>{this.state.data}</h2>
                <br/>
                <h2 className='container'> Child
                        <Content myDataProp = {this.state.data}
                        updateStateProp = {this.updateState}/>
                </h2>
            </div>



        );}
}


class Content extends React.Component{
    render(){
        return( 
            <div>
                <input type = "text" value = {this.props.myDataProp}
                onChange = {this.props.updateStateProp}/>
                <h3>{this.props.myDataProp}</h3>
            </div>
        );}
}