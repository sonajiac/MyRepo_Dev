import React, { Component } from 'react';


export default class DisplayText extends Component {
    constructor(props){
        super(props);
    }

    render(){
        var myStyle = {
            fontSize:20,
            color:'#FF0000'
        }

        return(
            <div style = {myStyle}>{this.props.text}</div>
        );}
}