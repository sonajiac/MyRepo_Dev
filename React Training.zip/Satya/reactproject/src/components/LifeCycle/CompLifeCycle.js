import React from 'react';
//import Parent from './ErrorHandlling';

// Note : *Will* hooks are going to be removed in future versions
export default class CompLifeCycle extends React.Component {

   constructor(props) {
      super(props);		
      this.state = {
         data: 0,
         msg: 'Initial data...',
         newmsg:'Nodata'
      }
      this.setNewNumber = this.setNewNumber.bind(this)
      this.updateState = this.updateState.bind(this);     
   };
   setNewNumber(e) {
      this.setState({data: this.state.data + 1})
   }
   updateState(e) {
      this.setState({msg:e.target.value});
   }      
   render() {
      return (
         <div>          
             <button  onClick = {this.setNewNumber}>INCREMENT</button>                       
            
             <Content myNumber = {this.state.data} ></Content>
            <br/>
             <input type = "text" value = {this.state.msg} 
               onChange = {this.updateState} />
             <h3>{this.state.msg}</h3>               
         </div>
      );
   }
}


//child code
class Content extends React.Component{
    constructor(props){
        super(props)
        console.log(props.myNumber);//0
        console.log("1.Content Constructor");
        this.handleScroll = this.handleScroll.bind(this);
    }

    componentWillMount(){
        console.log('1.will mount');
        console.log(this.props.myNumber);
    }

    handleScroll(){
        console.log('handleScroll executed');       
    }

    componentDidMount(){
        console.log('componentDidMount executed'); 
        console.log(this.props.myNumber);
        window.addEventListener('scroll',this.handleScroll);
    }

    componentWillReceiveProps(nextProps){
        console.log('3.componentWillReceiveProps executed'); 
        console.log(nextProps.myNumber);
        this.setState(
            {
             isPassed:nextProps.myNumber >=10   
            }
        );
    }

    shouldComponentUpdate(nextProps,nextState){
        console.log('4.shouldComponentUpdate executed'); 
        console.log(nextState);
        if(nextProps.myNumber > 10){
            console.log('component  rendered');
            return true;
        }
        return false;
    }

    componentWillUpdate(nextProps,nextState){
        console.log('5.componentWillUpdate executed'); 
    }

    componentDidUpdate(prevProps,prevState){
        console.log('7.componentDidUpdate executed'); 
    }

    componentWillUnmount(){
        console.log('8.componentWillUnmount executed'); 
        window.removeEventListener('scroll',this.handleScroll);
    }

    componentDidCatch(err){
        console.log('9.componentDidCatch executed'); 
    }

    render(){
        return(
            <div>
                <h3>{this.props.myNumber}</h3>
            </div>
        );
    }


}
//End of the code