import React from 'react';


//This is global context state 
const stateVar = {
    number:0,
    authToken:'aaaa',
    sessionId:'',
    isAuthencated: false
};

const NumberContext =  React.createContext(stateVar.number);

export default NumberContext;