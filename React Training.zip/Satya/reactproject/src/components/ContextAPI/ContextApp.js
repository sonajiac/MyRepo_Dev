import React, { Component } from 'react';

import "./Context.css";
import NumberContext from "./context";


const Counter = (props) =>{
    return(
        <NumberContext.Consumer>
            {val => <h1>{val}  💪 </h1>}    
        </NumberContext.Consumer>
    );
}


export default class ContextApp extends Component{
    constructor(props){
        super(props)
        this.state={
            number : 0
        };
        this.onDecHand = this.onDecHand.bind(this);
        this.onIncHand = this.onIncHand.bind(this);
    }

    onIncHand(){
        this.setState({
                number:this.state.number+1
            }            
        );
    }
    onDecHand(){
        this.setState({
                number:this.state.number-1
            }            
        );
    }

    render(){
        return(
            <div>
                <h1 className = "App-title">React Context Api v 16.3.1</h1>
                <NumberContext.Provider value = {this.state.number}>
                    <Counter/>
                </NumberContext.Provider>

                <button onClick = {this.onIncHand} >Increment</button>
                <button onClick = {this.onDecHand} >Decremrnt</button>
            </div>
        );
    }


}