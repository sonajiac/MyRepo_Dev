import React, { Component } from 'react';
import DisplayText from './DisplayText';

export default class TextInput extends Component {
    constructor(props){
        super(props);
        this.state = {inputText:"Satya"};        
    }

    handleChange(event){
        this.setState({
            inputText:event.target.value
        })
    }

    render(){
        return(
            <div>
                  <input type = "text" value = "Hello" />  
                  <div>Enter Name</div>   
                  <input type = "text" value = {this.state.inputText} onChange = {this.handleChange.bind(this)} /> 
                  <DisplayText text = {this.state.inputText} />
            </div>
        );
    }

}