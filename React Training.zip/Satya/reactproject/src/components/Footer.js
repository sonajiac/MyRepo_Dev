import React, { Component } from 'react';


class Footer extends Component {
    render() {
        return (
        <div>
            <h2 className = "text-info text-denter"> React Project </h2>
            <h3> Copyrights @ Satya </h3>
        </div>
        );
    }
}

export default Footer;