import React, { Component } from 'react';
import Header from './Header';
import Footer from './Footer';
import MyHOC from './MyHOC';
import ChildParentInvoke from './InterComp/ChildParentInvoke';
import ContextApp from './ContextAPI/ContextApp';
import UsingRefs from './InterComp/UsingRefs';
import CompLifeCycle from './LifeCycle/CompLifeCycle';
import WeatherComponent from './LifeCycle/RestDemo';

class Dashboard extends Component {
    render() {
        return (
        <div>
            <Header tt="React SPA Project"/>
            <WeatherComponent/>
            <Footer/>                       
        </div>
        );
    }
}

export default Dashboard;